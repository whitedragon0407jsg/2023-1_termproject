package com.example.dodgebomb

interface GameTask {
    fun closeGame(mScore : Int)
}